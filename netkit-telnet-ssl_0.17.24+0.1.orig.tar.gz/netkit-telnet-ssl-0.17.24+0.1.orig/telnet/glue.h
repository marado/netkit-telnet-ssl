void printsub_h(int direction, unsigned char *pointer, int length);
int netflush_h(void);
